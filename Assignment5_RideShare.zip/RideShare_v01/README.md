# Assignment 4

## Introduction

* Suppose that a new start-up is trying to create a rideshare app and hires you to design their
database. Think about the main information that the app must keep track of and create some
deliverables to show your client as you go.

## Identifying Information

* Name: Andriana Agrusa and Megnha Raswan
* Student ID: 2344125 and 2337415
* Email: agrusa@chapman.edu and raswan@chapman.edu
* Course: CPSC 408-01
* Assignment: Assignment 5

## Source Files

* RideShare.py
* README.md
* ridesharedatabasedump.sql
* Ride Share ER Diagram.pdf

## References

* Class Material

## Known Errors

* None

## Run Instructions

* To create the tables: run create() function
* To insert data: run insert_data() function
* To run the entire program: run new_or_returning() function
* python3 RideShare.py

